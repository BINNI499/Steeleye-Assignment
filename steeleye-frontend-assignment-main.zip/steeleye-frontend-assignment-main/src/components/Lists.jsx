import { memo } from "react";

import WrappedListComponent from "./WrappedList";

const List = memo(WrappedListComponent);

export default List;
